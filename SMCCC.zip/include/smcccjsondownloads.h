#ifndef SMCCCJSONDOWNLOADS_H
#define SMCCCJSONDOWNLOADS_H

class SMCCCJson;
class SMCCCJsonDownloads
{
public:
    SMCCCJsonDownloads();
    bool process(SMCCCJson *Json);
};

#endif // SMCCCJSONDOWNLOADS_H
