#ifndef SMCCCJSONINHERITSFROM_H
#define SMCCCJSONINHERITSFROM_H

class SMCCCJson;
class SMCCCJsonInheritsFrom
{
public:
    SMCCCJsonInheritsFrom();
    bool process(SMCCCJson *Json);
};

#endif // SMCCCJSONINHERITSFROM_H
